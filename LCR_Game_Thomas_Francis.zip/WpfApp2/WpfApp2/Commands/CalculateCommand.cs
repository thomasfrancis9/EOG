﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp2
{
    class CalculateCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private CalculationViewModel vm;

        public CalculateCommand(CalculationViewModel vm)
        {
            this.vm = vm;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            int games = int.Parse(vm.Games);
            int players = int.Parse(vm.Players);
            if(games > 1 && players >= 3)
            {
                ExecuteGamesAsync(games, players);
            }            
        }

        private async void ExecuteGamesAsync(int numberOfGames, int numberOfPlayers)
        {
            List<Task<int>> gamesTobeExecuted = new List<Task<int>>();

            for (int i = 0; i < numberOfGames; i++)
            {
                gamesTobeExecuted.Add(Task.Run(() => StartGame(numberOfPlayers)));
            }

            var results = await Task.WhenAll(gamesTobeExecuted);
            int shortTurn = int.MaxValue;
            int longTurn = 0;
            int shortestGame = 0;
            int longestGame = 0;
            int totalTurn = 0;

            for(int i =0; i<results.Length;i++)
            {
                if (results[i] < shortTurn)
                {
                    shortTurn = results[i];
                    shortestGame = i;
                }
                if (results[i] > longTurn)
                {
                    longTurn = results[i];
                    longestGame = i;
                }
                totalTurn += results[i];
            }
            vm.ShortestGame = (shortestGame + 1).ToString();
            vm.LongestGame = (longestGame + 1).ToString();

            //Finding out average turn game
            int averageGame = 0;
            int averageTurn = totalTurn / numberOfGames;

            int turnDifference = longTurn;
            int currentDifference = longTurn;
            for (int i = 0; i < results.Length; i++)
            {
                currentDifference = Math.Abs(averageTurn - results[i]);
                if (currentDifference < turnDifference)
                {
                    turnDifference = currentDifference;
                    averageGame = i;
                }
            }
            vm.AverageGame = (averageGame + 1).ToString();
        }

        private void roll(int player_index, int[] player_scores, int player_count)
        {
            Random rnd = new Random();
            int rollOutput = rnd.Next(1, 6);
            if (rollOutput < 4)
            {
                //Do nothing. This is the dot case
            }
            else if (rollOutput == 4)
            {
                // Right
                player_scores[player_index] -= 1;

                if(player_index == player_count - 1)
                {
                    player_scores[0] += 1;
                }
                else
                {
                    player_scores[player_index + 1] += 1;
                }                
            }
            else if (rollOutput == 5)
            {
                // Left
                player_scores[player_index] -= 1;
                if(player_index == 0)
                {
                    player_scores[player_count - 1] += 1;
                }
                else
                {
                    player_scores[player_index - 1] += 1;
                }
            }
            else if (rollOutput == 6)
            {
                // Center
                player_scores[player_index] -= 1;
            }
            else
            {
                //Log error
            }
        }

        private int StartGame(int num_players)
        {
            int numberOfTurns = 0;
            int[] player_scores = new int[num_players];

            // Initial scores of players
            for(int i = 0; i < num_players; i++)
            {
                player_scores[i] = 3;
            }

            int activePlayerCount = GetActivePlayerCount(player_scores);
            
            while (activePlayerCount > 1)
            {
                int player_index = 0;
                while (player_index < num_players)
                {
                    activePlayerCount = GetActivePlayerCount(player_scores);
                    if (activePlayerCount == 1)
                    {
                        //End of game, only one person left with chips                     
                        break;
                    }
                    else if (player_scores[player_index] == 0)
                    {
                        // Do nothing this person doesnt have chips to play
                    }
                    else if (player_scores[player_index] >= 3)
                    {
                        // if player has three or more chips
                        for (int i = 0; i < 3; i++)
                        {
                            roll(player_index, player_scores, num_players);
                            numberOfTurns++;
                        }
                    }
                    else if (player_scores[player_index] == 2)
                    {
                        // Player has only 2 chips
                        for (int i = 0; i < 2; i++)
                        {
                            roll(player_index, player_scores, num_players);
                            numberOfTurns++;
                        }
                    }
                    else if (player_scores[player_index] == 1)
                    {
                        // Has only 1 chip
                        roll(player_index, player_scores, num_players);
                        numberOfTurns++;
                    }
                    else
                    {
                        //log error.
                    }

                    player_index += 1;
                }
            }

            return numberOfTurns;
        }

        private int GetActivePlayerCount(int[] player_scores)
        {
            int playerCount = 0;
            foreach (int score in player_scores)
            {
                if (score > 0)
                {
                    playerCount++;
                }                
            }
            return playerCount;
        }
    }
}
