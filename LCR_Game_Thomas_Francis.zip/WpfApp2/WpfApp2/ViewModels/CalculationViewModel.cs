﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Input;

namespace WpfApp2
{


    public class CalculationViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ICommand command;
        private int calculationResult;
        List<string> list = new List<string>(10);
        private string games;
        private string players;
        private string shortestGame;
        private string longestGame;
        private string averageGame;

        public CalculationViewModel()
        {
            CalculateCommand = new CalculateCommand(this);
        }

        public ICommand CalculateCommand
        {
            get
            {
                return command;                
            }
            set
            {
                command = value;
            }
        }

        public String Games
        {
            get
            {
                return games;
            }
            set
            {
                games = value;
                OnPropertyChanged("Games");
            }
        }

        public string Players
        {
            get
            {
                return players;
            }
            set
            {
                players = value;
                OnPropertyChanged("Players");
            }
        }

        public string ShortestGame
        {
            get
            {
                return shortestGame;
            }
            set
            {
                shortestGame = value;
                OnPropertyChanged("ShortestGame");
            }
        }

        public string LongestGame
        {
            get
            {
                return longestGame;
            }
            set
            {
                longestGame = value;
                OnPropertyChanged("LongestGame");
            }
        }

        public string AverageGame
        {
            get
            {
                return averageGame;
            }
            set
            {
                averageGame = value;
                OnPropertyChanged("AverageGame");
            }
        }

        public int CalculationResult
        {
            get
            {
                return calculationResult;
            }
            set
            {
                calculationResult = value;
                OnPropertyChanged("CalculationResult");
            }
        }

        private void OnPropertyChanged(string property)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
